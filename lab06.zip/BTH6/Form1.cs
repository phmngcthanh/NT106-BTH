﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace BTH6
{
    public partial class Form1 : Form
    {
        FtpClient conn;

        int Init;
        public Form1()
        {
            InitializeComponent();
            Init = 0;
            tbxrmtpath.Enabled = false;
            btnrmtBrowse.Enabled = false;
            tbxlclpath.Enabled = false;
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void tableLayoutPanel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void label4_Click(object sender, EventArgs e)
        {

        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)

        {
            int validInput = 0;

            //check input boxes
           if (tbxhost.Text.Length > 0)
            {
                if (tbxuser.Text.Length > 0)
                    if (tbxpass.Text.Length > 0)
                        validInput = 1;
                if (tbxuser.Text == "anonymous")
                {
                    if (tbxpass.Text.Length == 0)
                        tbxpass.Text = "anonymous";
                    validInput = 1;

                }

            }

            if (validInput == 0)
            { 
                MessageBox.Show("vui long nhap host va/hoac username");
                return;
            }
        
            conn = new FtpClient(tbxhost.Text, tbxuser.Text, tbxpass.Text);
            Init = 1;

            tbxrmtpath.Enabled = true;
            btnrmtBrowse.Enabled = true;
            tbxrmtpath.Text = "/";

            rmtGetFileInDir("");
        }

        private void label6_Click(object sender, EventArgs e)
        {

        }

        private void tbxrmtpath_TextChanged(object sender, EventArgs e)
        {

        }
        public void lclGetFileInDir(string filepath)
        {
         
                string path = System.IO.Path.GetFullPath(filepath);
                 var files = Directory.EnumerateFiles(path, "*.*", SearchOption.TopDirectoryOnly);
                int NumOfFiles = 0;
                string abc = "";
                foreach (string file in files)
                {
                    NumOfFiles++;
                    abc += file + " ";
                }
                listView1.Clear();
                string[] a = new String[NumOfFiles];

                a = null;
                int i = 0;
                foreach (string file in files)
                {

                    ListViewItem item = new ListViewItem(System.IO.Path.GetFileName(file));
                    item.SubItems.Add(file);
                    listView1.Items.Add(item);

                    i++;


                }
            tbxlclpath.Text = filepath;
                // CallErrorBox(abc);
                //CallErrorBox((OrderOfActingFileInList.ToString()));
            
       
        }

        public void rmtGetFileInDir(string filepath)
        {

            if (filepath == "/") filepath = "";
            var files = conn.directoryListSimple(filepath);

            int NumOfFiles = 0;
            string abc = "";
            foreach (string file in files)
            {
                NumOfFiles++;
                abc += file + " ";

            }
            listView2.Clear();
            string[] a = new String[NumOfFiles];


            a = null;
            int i = 0;
            foreach (string file in files)
            {

                ListViewItem item = new ListViewItem(System.IO.Path.GetFileName(file));
                item.SubItems.Add(file);
                listView2.Items.Add(item);

                i++;


            }
            // CallErrorBox(abc);
            //CallErrorBox((OrderOfActingFileInList.ToString()));


        }
        private void btnlclBrowse_Click(object sender, EventArgs e)
        {
            FolderBrowserDialog open = new FolderBrowserDialog();
                          
            if (open.ShowDialog() == DialogResult.OK)
            {
                // display image in picture box  

                lclGetFileInDir(open.SelectedPath);
                tbxlclpath.Text = open.SelectedPath.ToString();
                // image file path  
                //textBox1.Text = open.FileName;
            }
        }

        private void btnrmtBrowse_Click(object sender, EventArgs e)
        {
            rmtGetFileInDir(tbxrmtpath.Text);
        }

        private void listView1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void btnUpload_Click(object sender, EventArgs e)
        {
            if (listView1.SelectedItems.Count>0)
            {
                foreach(var File in listView1.SelectedItems)
                {
                    conn.upload(tbxrmtpath + File.ToString(), tbxlclpath + File.ToString());
                    
                }    
            }
        }

        private void btnDownload_Click(object sender, EventArgs e)
        {
            if (listView2.SelectedItems.Count > 0)
            {
                foreach (var File in listView2.SelectedItems)
                {
                    conn.download(tbxrmtpath + File.ToString(), tbxlclpath + File.ToString());

                }
            }
        }
    }
}

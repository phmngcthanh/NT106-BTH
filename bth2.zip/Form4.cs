﻿using System;
using System.IO;
using System.Windows.Forms;

namespace BTH_19520958
{
    public partial class Form4 : Form
    {
        public Form4()
        {
            InitializeComponent();
        }
        private void Form_FormIsClosed(object sender, FormClosedEventArgs e)
        {
            this.Hide();
            MainForm fm = new MainForm();
            fm.ShowDialog();
            this.Dispose();
        }
        private void Form4_Load(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            OpenFileDialog ofd = new OpenFileDialog();
            ofd.ShowDialog();
            FileStream fs = new FileStream(ofd.FileName, FileMode.OpenOrCreate);
            StreamReader sr = new StreamReader(fs);
            string content = sr.ReadToEnd();
            sr.Close();
            fs.Close();
            FileStream fr = new FileStream(ofd.FileName, FileMode.Append);
            StreamWriter sw = new StreamWriter(fr);
            content = content.Replace("\r\n", "\n");
            string[] xuly = content.Split('\n');
            double Diem1 = double.Parse(xuly[3]);
            double Diem2 = double.Parse(xuly[4]);
            double diemTB = (Diem1 + Diem2) / 2;
            sw.WriteLine();
            sw.Write(Math.Round(diemTB, 1).ToString());
            sw.Close();
            fr.Close();
        }
    }
}

﻿using System;
using System.Windows.Forms;

namespace BTH_19520958
{
    public partial class MainForm : Form
    {
        public MainForm()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Form1 fm= new Form1();
            this.Hide();
            fm.ShowDialog();
            
        }

        private void button6_Click(object sender, EventArgs e)
        {
            Form2 fm = new Form2();
            this.Hide();
            fm.ShowDialog();
            
        }

        private void button5_Click(object sender, EventArgs e)
        {
            Form3 fm = new Form3();
            this.Hide();
            fm.ShowDialog();
            
        }

        private void button4_Click(object sender, EventArgs e)
        {
            Form4 fm = new Form4();
            this.Hide();
            fm.ShowDialog();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            Form5 fm = new Form5();
            this.Hide();
            fm.ShowDialog();
         
        }
        private void MainForm_FormIsClosed(object sender, FormClosedEventArgs e)
        {
            /* resolve problem when open other form and application not close when click X on main form*/
            Application.Exit();
            this.Dispose();
        }
        private void MainForm_Load(object sender, EventArgs e)
        {

        }
    }
}

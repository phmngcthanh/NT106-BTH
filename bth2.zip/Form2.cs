﻿using System;
using System.IO;
using System.Linq;
using System.Windows.Forms;

namespace BTH_19520958
{
    public partial class Form2 : Form
    {
        public Form2()
        {
            InitializeComponent();
        }
        private void Form_FormIsClosed(object sender, FormClosedEventArgs e)
        {
            this.Hide();
            MainForm fm = new MainForm();
            fm.ShowDialog();
            this.Dispose();
        }
        private void Form2_Load(object sender, EventArgs e)
        {

        }

        private void richTextBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            OpenFileDialog ofd = new OpenFileDialog();
            ofd.ShowDialog();
            FileStream fs = new FileStream(ofd.FileName, FileMode.OpenOrCreate);
            StreamReader sr = new StreamReader(fs);
            string content = sr.ReadToEnd();
            richTextBox1.Text = content;
            textBox1.Text = ofd.SafeFileName.ToString();
            textBox2.Text = ofd.FileName.ToString();
            content = content.Replace("\r\n", " ");
            textBox3.Text = richTextBox1.Lines.Count().ToString();
            string[] wcount = content.Split(new char[] { '.', '?', '!', ' ', ';', ':', ',' },StringSplitOptions.RemoveEmptyEntries);
            textBox4.Text = wcount.Count().ToString();
            int charcount = 0;
            foreach( string word in wcount)
            {
                charcount += word.Count();
            }
            textBox5.Text = charcount.ToString();
            fs.Close();
        }

        private void textBox5_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox3_TextChanged(object sender, EventArgs e)
        {

        }
    }
}

﻿using System;
using System.IO;
using System.Windows.Forms;

namespace BTH_19520958
{
    public partial class Form5 : Form
    {
        public Form5()
        {
            InitializeComponent();
        }
        private void Form_FormIsClosed(object sender, FormClosedEventArgs e)
        {
            this.Hide();
            MainForm fm = new MainForm();
            fm.ShowDialog();

            this.Dispose();
        }
        private void Form5_Load(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            FolderBrowserDialog fd = new FolderBrowserDialog();
            fd.ShowDialog();
            ListViewItem lvi;
            ListViewItem.ListViewSubItem lvsi;
            DirectoryInfo di = new DirectoryInfo(fd.SelectedPath);
            FileInfo[] files = di.GetFiles();
            
            foreach (System.IO.FileInfo fi in files)
            {
                lvi = new ListViewItem();
                lvi.Text = fi.Name;
                lvi.Tag = fi.FullName;

                lvsi = new ListViewItem.ListViewSubItem();
                lvsi.Text = fi.Length.ToString();
                lvi.SubItems.Add(lvsi);
                lvsi = new ListViewItem.ListViewSubItem();
                lvsi.Text = fi.Extension.ToString();
                lvi.SubItems.Add(lvsi);
                lvsi = new ListViewItem.ListViewSubItem();
                lvsi.Text = fi.LastAccessTime.ToString();
                lvi.SubItems.Add(lvsi);

                listView1.Items.Add(lvi);
            }
        }

        private void richTextBox1_TextChanged(object sender, EventArgs e)
        {

        }

    }
}

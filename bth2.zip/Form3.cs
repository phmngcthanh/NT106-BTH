﻿using System;
using System.IO;
using System.Linq;
using System.Windows.Forms;

namespace BTH_19520958
{
    public partial class Form3 : Form
    {
        public Form3()
        {
            InitializeComponent();
        }
        private void Form_FormIsClosed(object sender, FormClosedEventArgs e)
        {
            this.Hide();
            MainForm fm = new MainForm();
            fm.ShowDialog();
            this.Dispose();
        }

        private long Execute(string payload)
        {
            char[] ToanTu = { '+', '-', '*', '/' };
            char toantu=' ';
            foreach (char a in ToanTu)
            {
                if (payload.Contains(a))
                    toantu = a;
                    

            }

            string[] toanhang = payload.Split(ToanTu, StringSplitOptions.RemoveEmptyEntries);
            int sohang1 = 0;
            int sohang2 = 0;
            if (toanhang.Length == 1)
                return int.Parse(toanhang[0]);
            sohang1 = int.Parse(toanhang[0]);
            sohang2 = int.Parse(toanhang[1]);
            switch (toantu)
            {
                case '+':
                    return sohang1 + sohang2;
                case '-':
                    return sohang1 - sohang2;
                case '*':
                    return sohang1 * sohang2;
                case '/':
                    return (int)((int)sohang1 / (int)sohang2);
            }
            return 0;
        }
        private void Form3_Load(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            OpenFileDialog ofd = new OpenFileDialog();
            ofd.ShowDialog();
            FileStream fs = new FileStream(ofd.FileName, FileMode.OpenOrCreate);
            StreamReader sr = new StreamReader(fs);
            string content = sr.ReadToEnd();
            sr.Close();
            fs.Close();
            FileStream fr = new FileStream(ofd.FileName, FileMode.Create);
            StreamWriter sw = new StreamWriter(fr);
            content = content.Replace("\r\n", "\n");
            string[] xuly = content.Split( '\n');
            foreach( string i in xuly)
            {
                long x = Execute(i);
                    
                string g = x.ToString();
                sw.WriteLine(i + "=" + g);
            }
            sw.Close();
            fr.Close();
        }

        private void richTextBox1_TextChanged(object sender, EventArgs e)
        {

        }
    }
}

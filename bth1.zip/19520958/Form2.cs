﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace _19520958
{
    public partial class Form2 : Form
    {
        public Form2()
        {
            InitializeComponent();
            richTextBox1.Text = "Phần mềm xử lý điểm sinh viên\n";
            richTextBox1.Text += "Vui lòng nhập điểm, ngăn cách bằng dấu phẩy";
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            //Kiểm tra điều kiện ngữ nghĩa
            richTextBox1.Text = "";
            string AllowedCharacters = "0123456789,.";
            int i = 0;
            bool Qualified = true;
            foreach (char Check in textBox1.Text) 
            { if (!(AllowedCharacters.Contains(Check)))
                {
                    richTextBox1.Text += "Vui lòng nhập điểm theo format đề bài";
                    Qualified = false;
                }
                i++;
            }

            
            //Parse ra điểm và kiểm tra giá trị điểm
            string[] ListDiem = (textBox1.Text).Split(',');
            double[] diem = new double[i];
            string HocLuc = "Chưa Phân Loại";
            //Nếu pass qua kiểm tra ngữ nghĩa
            if (Qualified)
            {
                i = 0;
                foreach (string Diem in ListDiem)
                {
                    try
                    {
                        if (Diem.Length > 0)
                        {
                            diem[i] = Convert.ToDouble(Diem);
                            if (diem[i] > 10 || diem[i] < 0)
                            {   //kiểm tra giá trị
                                richTextBox1.Text = "Vui lòng nhập điểm bé hơn 10, lớn hơn hoặc bằng 0";
                                Qualified = false;
                                break;
                            }
                            richTextBox1.Text += Diem + "-\n";
                            i++;
                        }
                    }
                    catch (Exception)
                    {
                        richTextBox1.Text = "Vui lòng nhập điểm bé hơn 10, lớn hơn hoặc bằng 0";
                        Qualified = false;
                    }
                }
            }
            if (Qualified)
            {
                //tính điểm trung bình, parse điểm các môn, tìm điểm thấp nhất
                int SoMonHoc = i;
                double DiemTrungBinh = 0.0;
                double DiemThapNhat = 10.0;
                double DiemCaoNhat = 0.0;
                const double DiemQuaMon = 5.0;
                int MonRot = 0;
                for (int k=0;k<SoMonHoc;k++)
                {
                    DiemTrungBinh += diem[k];
                    if (diem[k] < DiemThapNhat)
                        DiemThapNhat = diem[k];
                    if (DiemCaoNhat < diem[k])
                        DiemCaoNhat = diem[k];
                    if (diem[k] < DiemQuaMon)
                        MonRot++;
                }
                DiemTrungBinh = DiemTrungBinh / SoMonHoc;
                int MonDau = SoMonHoc - MonRot;
                    
                //Xet  theo Diem Thap Nhat
                if (DiemThapNhat < 2.0)
                {
                    HocLuc = "Kém";
                }
                else
                if (DiemThapNhat < 3.5)
                {
                    HocLuc = "Yếu";
                }
                else
                if (DiemThapNhat < 5.0)
                {
                    HocLuc = "Trung Bình";
                }
                else
                if (DiemThapNhat < 6.5)
                {
                    HocLuc = "Khá";
                }
                else
                    HocLuc = "Giỏi";

                richTextBox1.Text = "Chương trình xếp loại sinh viên\n";

                richTextBox1.Text+= "Đã nhập "+ SoMonHoc + " môn học\n";
                
                for (int k = 1; k <= SoMonHoc; k++)
                {
                    richTextBox1.Text += "Môn " + k + ": " + diem[k] + "  ";
                }
                richTextBox1.Text += "\n" + "Điểm trung bình: " + DiemTrungBinh+"\n";
                richTextBox1.Text += "Điểm cao nhất: " + DiemCaoNhat + " , Điểm thấp nhất: " + DiemThapNhat + "\n";
                richTextBox1.Text += "Đậu " + MonDau + " môn, rớt " + MonRot + " môn \n";
                richTextBox1.Text += "Xếp loại :" + HocLuc;


            }






        }

        private void richTextBox1_TextChanged(object sender, EventArgs e)
        {
            
        }

        private void Form2_Load(object sender, EventArgs e)
        {

        }
        private void Form2_FormIsClosed(object sender, FormClosedEventArgs e)
        {

            Form1 fm = new Form1();

            fm.Show();

        }
    }
}

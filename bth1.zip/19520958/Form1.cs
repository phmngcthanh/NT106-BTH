﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace _19520958
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Form2 NewForm = new Form2();
            this.Hide();
            NewForm.ShowDialog();

        }
        private void MainBox_FormIsClosed(object sender, FormClosedEventArgs e)
        {
            /* resolve problem when open other form and application not close when click X on main form*/
            Application.Exit();
            this.Dispose();
        }
    }
}

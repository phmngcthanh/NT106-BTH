﻿
namespace Lab03_Bai02
{
    partial class Lab03_Bai02
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.bttn_Listen = new System.Windows.Forms.Button();
            this.ListView_Commands = new System.Windows.Forms.ListView();
            this.label1 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // bttn_Listen
            // 
            this.bttn_Listen.Location = new System.Drawing.Point(276, 18);
            this.bttn_Listen.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.bttn_Listen.Name = "bttn_Listen";
            this.bttn_Listen.Size = new System.Drawing.Size(108, 31);
            this.bttn_Listen.TabIndex = 0;
            this.bttn_Listen.Text = "Listen";
            this.bttn_Listen.UseVisualStyleBackColor = true;
            this.bttn_Listen.Click += new System.EventHandler(this.bttn_Listen_Click);
            // 
            // ListView_Commands
            // 
            this.ListView_Commands.HideSelection = false;
            this.ListView_Commands.Location = new System.Drawing.Point(27, 62);
            this.ListView_Commands.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.ListView_Commands.Name = "ListView_Commands";
            this.ListView_Commands.Size = new System.Drawing.Size(357, 246);
            this.ListView_Commands.TabIndex = 2;
            this.ListView_Commands.UseCompatibleStateImageBehavior = false;
            this.ListView_Commands.View = System.Windows.Forms.View.List;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(27, 4);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(165, 45);
            this.label1.TabIndex = 3;
            this.label1.Text = "DSSV: \r\nPhạm Ngọc Thành - 19520958\r\nPhạm Bảo Hà - 19521457";
            this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // Lab03_Bai02
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(410, 330);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.ListView_Commands);
            this.Controls.Add(this.bttn_Listen);
            this.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.Name = "Lab03_Bai02";
            this.Text = "Bài 02";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.Listener_FormClosing);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button bttn_Listen;
        private System.Windows.Forms.ListView ListView_Commands;
        private System.Windows.Forms.Label label1;
    }
}


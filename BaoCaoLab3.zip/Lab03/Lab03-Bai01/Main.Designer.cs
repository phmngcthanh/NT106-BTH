﻿
namespace Lab03_Bai01
{
    partial class Main
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.bttn_Client = new System.Windows.Forms.Button();
            this.bttn_Server = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // bttn_Client
            // 
            this.bttn_Client.Location = new System.Drawing.Point(54, 40);
            this.bttn_Client.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.bttn_Client.Name = "bttn_Client";
            this.bttn_Client.Size = new System.Drawing.Size(130, 44);
            this.bttn_Client.TabIndex = 0;
            this.bttn_Client.Text = "Client";
            this.bttn_Client.UseVisualStyleBackColor = true;
            this.bttn_Client.Click += new System.EventHandler(this.bttn_Client_Click);
            // 
            // bttn_Server
            // 
            this.bttn_Server.Location = new System.Drawing.Point(246, 40);
            this.bttn_Server.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.bttn_Server.Name = "bttn_Server";
            this.bttn_Server.Size = new System.Drawing.Size(130, 44);
            this.bttn_Server.TabIndex = 1;
            this.bttn_Server.Text = "Server";
            this.bttn_Server.UseVisualStyleBackColor = true;
            this.bttn_Server.Click += new System.EventHandler(this.bttn_Server_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(136, 113);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(165, 45);
            this.label1.TabIndex = 2;
            this.label1.Text = "DSSV: \r\nPhạm Ngọc Thành - 19520958\r\nPhạm Bảo Hà - 19521457";
            this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.label1.Click += new System.EventHandler(this.label1_Click);
            // 
            // Main
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(428, 199);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.bttn_Server);
            this.Controls.Add(this.bttn_Client);
            this.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.Name = "Main";
            this.Text = "Bài 01";
            this.Load += new System.EventHandler(this.Lab03_Bai01_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button bttn_Client;
        private System.Windows.Forms.Button bttn_Server;
        private System.Windows.Forms.Label label1;
    }
}


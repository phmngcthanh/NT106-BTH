Tại vì Bài 4 hơi phức tạp, em xin phép tách riêng project ở folder Lab04-Bai04.
Bài 1,2,3 ở folder Lab04.
EM xin cảm ơn
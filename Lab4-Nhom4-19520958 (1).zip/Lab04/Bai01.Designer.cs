﻿
namespace Lab04
{
    partial class Bai01
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.RichTextBox_Link = new System.Windows.Forms.RichTextBox();
            this.button_GET = new System.Windows.Forms.Button();
            this.RichTextBox_GET = new System.Windows.Forms.RichTextBox();
            this.SuspendLayout();
            // 
            // RichTextBox_Link
            // 
            this.RichTextBox_Link.Location = new System.Drawing.Point(12, 28);
            this.RichTextBox_Link.Multiline = false;
            this.RichTextBox_Link.Name = "RichTextBox_Link";
            this.RichTextBox_Link.Size = new System.Drawing.Size(545, 35);
            this.RichTextBox_Link.TabIndex = 0;
            this.RichTextBox_Link.Text = "";
            // 
            // button_GET
            // 
            this.button_GET.Location = new System.Drawing.Point(592, 28);
            this.button_GET.Name = "button_GET";
            this.button_GET.Size = new System.Drawing.Size(132, 35);
            this.button_GET.TabIndex = 1;
            this.button_GET.Text = "GET";
            this.button_GET.UseVisualStyleBackColor = true;
            this.button_GET.Click += new System.EventHandler(this.button_GET_Click);
            // 
            // RichTextBox_GET
            // 
            this.RichTextBox_GET.Location = new System.Drawing.Point(12, 93);
            this.RichTextBox_GET.Name = "RichTextBox_GET";
            this.RichTextBox_GET.ReadOnly = true;
            this.RichTextBox_GET.Size = new System.Drawing.Size(712, 359);
            this.RichTextBox_GET.TabIndex = 2;
            this.RichTextBox_GET.Text = "";
            // 
            // Bai01
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(736, 478);
            this.Controls.Add(this.RichTextBox_GET);
            this.Controls.Add(this.button_GET);
            this.Controls.Add(this.RichTextBox_Link);
            this.Name = "Bai01";
            this.Text = "Bài 01";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.RichTextBox RichTextBox_Link;
        private System.Windows.Forms.Button button_GET;
        private System.Windows.Forms.RichTextBox RichTextBox_GET;
    }
}
﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Net;
using System.IO;

namespace Lab04
{
    public partial class Bai03 : Form
    {
        public Bai03()
        {
            InitializeComponent();
        }

        private void button_GET_Click(object sender, EventArgs e)
        {
            try
            {
                WebClient newClient = new WebClient();
                Stream response = newClient.OpenRead(RichTextBox_URL.Text);
                newClient.DownloadFile(RichTextBox_URL.Text, RichTextBox_Dir.Text);

                StreamReader responseReader = new StreamReader(response);

                RichTextBox_Content.Text = responseReader.ReadToEnd();

                responseReader.Close();
                response.Close();
            }
            catch (Exception)
            {
                string Error = "Please check the URL and the file directory. The error can be due to:\n" +
                    "- Incorrect URL or the website is not working\n" +
                    "- Incorrect file directory (Must include filename and extension. Default folder is the folder containing the program)";
                MessageBox.Show(Error, "Error");
            }
        }

        private void RichTextBox_URL_TextChanged(object sender, EventArgs e)
        {

        }
    }
}

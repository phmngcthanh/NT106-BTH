﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Net;
using System.IO;
using Microsoft.VisualBasic;

namespace Lab04
{
    public partial class Bai01 : Form
    {
        public Bai01()
        {
            InitializeComponent();
        }
        //check whether url is accessible
        private bool checkURL(string url)
        {
          
            try
            {
                HttpWebRequest request = WebRequest.Create(url) as HttpWebRequest;
                request.Method = "HEAD";
                HttpWebResponse response = request.GetResponse() as HttpWebResponse;
                return (response.StatusCode == HttpStatusCode.OK);
               /* response.Close();
                MessageBox.Show(response.StatusCode.ToString());*/
              
            }
            catch 
            {
                return false;
            }
        }
        private void button_GET_Click(object sender, EventArgs e)
        {
            if (RichTextBox_Link.Text == "")
                MessageBox.Show("URL rong thi biet truy cap gi ne", "URL ERROR", MessageBoxButtons.OK);
            else
            {
                bool x = RichTextBox_Link.Text.Contains("http://") | RichTextBox_Link.Text.Contains("https://");
                
                if (x == false)
                {
                    RichTextBox_Link.Text = "http://" + RichTextBox_Link.Text;

                }
                bool check = checkURL(RichTextBox_Link.Text);
                if (check == true)
                {
                   
                WebRequest request = WebRequest.Create(RichTextBox_Link.Text);
                WebResponse response = request.GetResponse();
                Stream dataStream = response.GetResponseStream();
                StreamReader reader = new StreamReader(dataStream);
                string serverResponse = reader.ReadToEnd();
                RichTextBox_GET.Text = serverResponse;
                response.Close();
          
                }
                else MessageBox.Show("Khong truy cap duoc roi", "URL ERROR", MessageBoxButtons.OK);
            }
        }
    }
}

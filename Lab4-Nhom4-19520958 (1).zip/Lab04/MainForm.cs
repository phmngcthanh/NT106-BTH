﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Lab04
{
    public partial class MainForm : Form
    {
        public MainForm()
        {
            InitializeComponent();
        }

        private void Button_Bai01_Click(object sender, EventArgs e)
        {
            Bai01 FormBai01 = new Bai01();
            FormBai01.Show();
        }

        private void button_Bai02_Click(object sender, EventArgs e)
        {
            Form1 FormBai02 = new Form1();
            FormBai02.Show();
        }

        private void button_Bai03_Click(object sender, EventArgs e)
        {
            Bai03 FormBai03 = new Bai03();
            FormBai03.Show();
        }

        private void button_Bai04_Click(object sender, EventArgs e)
        {
            
        }

        private void Label_HoTen_Click(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }
    }
}

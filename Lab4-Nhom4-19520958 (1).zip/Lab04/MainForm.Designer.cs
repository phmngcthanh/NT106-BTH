﻿
namespace Lab04
{
    partial class MainForm
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.Button_Bai01 = new System.Windows.Forms.Button();
            this.tableLayoutPanel1 = new System.Windows.Forms.TableLayoutPanel();
            this.button_Bai02 = new System.Windows.Forms.Button();
            this.button_Bai03 = new System.Windows.Forms.Button();
            this.Label_HoTen = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.tableLayoutPanel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // Button_Bai01
            // 
            this.Button_Bai01.Location = new System.Drawing.Point(3, 2);
            this.Button_Bai01.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.Button_Bai01.Name = "Button_Bai01";
            this.Button_Bai01.Size = new System.Drawing.Size(181, 91);
            this.Button_Bai01.TabIndex = 0;
            this.Button_Bai01.Text = "Bài 01";
            this.Button_Bai01.UseVisualStyleBackColor = true;
            this.Button_Bai01.Click += new System.EventHandler(this.Button_Bai01_Click);
            // 
            // tableLayoutPanel1
            // 
            this.tableLayoutPanel1.ColumnCount = 1;
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel1.Controls.Add(this.Button_Bai01, 0, 0);
            this.tableLayoutPanel1.Controls.Add(this.button_Bai02, 0, 1);
            this.tableLayoutPanel1.Controls.Add(this.button_Bai03, 0, 2);
            this.tableLayoutPanel1.Location = new System.Drawing.Point(31, 27);
            this.tableLayoutPanel1.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.tableLayoutPanel1.Name = "tableLayoutPanel1";
            this.tableLayoutPanel1.RowCount = 3;
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 33.33333F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 33.33333F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 33.33333F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 15F));
            this.tableLayoutPanel1.Size = new System.Drawing.Size(187, 287);
            this.tableLayoutPanel1.TabIndex = 1;
            // 
            // button_Bai02
            // 
            this.button_Bai02.Location = new System.Drawing.Point(3, 97);
            this.button_Bai02.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.button_Bai02.Name = "button_Bai02";
            this.button_Bai02.Size = new System.Drawing.Size(181, 91);
            this.button_Bai02.TabIndex = 1;
            this.button_Bai02.Text = "Bài 02";
            this.button_Bai02.UseVisualStyleBackColor = true;
            this.button_Bai02.Click += new System.EventHandler(this.button_Bai02_Click);
            // 
            // button_Bai03
            // 
            this.button_Bai03.Location = new System.Drawing.Point(3, 192);
            this.button_Bai03.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.button_Bai03.Name = "button_Bai03";
            this.button_Bai03.Size = new System.Drawing.Size(181, 92);
            this.button_Bai03.TabIndex = 2;
            this.button_Bai03.Text = "Bài 03";
            this.button_Bai03.UseVisualStyleBackColor = true;
            this.button_Bai03.Click += new System.EventHandler(this.button_Bai03_Click);
            // 
            // Label_HoTen
            // 
            this.Label_HoTen.AutoSize = true;
            this.Label_HoTen.Location = new System.Drawing.Point(469, 238);
            this.Label_HoTen.Name = "Label_HoTen";
            this.Label_HoTen.Size = new System.Drawing.Size(157, 30);
            this.Label_HoTen.TabIndex = 2;
            this.Label_HoTen.Text = "Phạm Ngọc Thành 19520958\r\nPhạm Bảo Hà 19521457";
            this.Label_HoTen.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.Label_HoTen.Click += new System.EventHandler(this.Label_HoTen_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(444, 277);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(244, 15);
            this.label1.TabIndex = 3;
            this.label1.Text = "Bài 4 chúng em xin phép để ở Solution riêng ";
            this.label1.Click += new System.EventHandler(this.label1_Click);
            // 
            // MainForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(700, 338);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.Label_HoTen);
            this.Controls.Add(this.tableLayoutPanel1);
            this.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.Name = "MainForm";
            this.Text = "Main";
            this.tableLayoutPanel1.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button Button_Bai01;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel1;
        private System.Windows.Forms.Button button_Bai02;
        private System.Windows.Forms.Button button_Bai03;
        private System.Windows.Forms.Label Label_HoTen;
        private System.Windows.Forms.Label label1;
    }
}


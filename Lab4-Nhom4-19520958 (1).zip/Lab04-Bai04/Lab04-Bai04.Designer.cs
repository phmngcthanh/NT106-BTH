﻿
namespace Lab04_Bai04
{
    partial class Bai04_Main
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.MyWebBrowser = new System.Windows.Forms.WebBrowser();
            this.tableLayoutPanel1 = new System.Windows.Forms.TableLayoutPanel();
            this.button1 = new System.Windows.Forms.Button();
            this.button_Download = new System.Windows.Forms.Button();
            this.button_Source = new System.Windows.Forms.Button();
            this.button_Go = new System.Windows.Forms.Button();
            this.RichTextBox_URL = new System.Windows.Forms.RichTextBox();
            this.button2 = new System.Windows.Forms.Button();
            this.ProgressBar_Download = new System.Windows.Forms.ProgressBar();
            this.tableLayoutPanel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // MyWebBrowser
            // 
            this.MyWebBrowser.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.MyWebBrowser.Location = new System.Drawing.Point(9, 55);
            this.MyWebBrowser.Margin = new System.Windows.Forms.Padding(2);
            this.MyWebBrowser.MinimumSize = new System.Drawing.Size(15, 16);
            this.MyWebBrowser.Name = "MyWebBrowser";
            this.MyWebBrowser.Size = new System.Drawing.Size(770, 331);
            this.MyWebBrowser.TabIndex = 0;
            this.MyWebBrowser.DocumentCompleted += new System.Windows.Forms.WebBrowserDocumentCompletedEventHandler(this.MyWebBrowser_DocumentCompleted_1);
            // 
            // tableLayoutPanel1
            // 
            this.tableLayoutPanel1.ColumnCount = 6;
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 10F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 10F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 10F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 10F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 10F));
            this.tableLayoutPanel1.Controls.Add(this.button1, 1, 0);
            this.tableLayoutPanel1.Controls.Add(this.button_Download, 5, 0);
            this.tableLayoutPanel1.Controls.Add(this.button_Source, 4, 0);
            this.tableLayoutPanel1.Controls.Add(this.button_Go, 3, 0);
            this.tableLayoutPanel1.Controls.Add(this.RichTextBox_URL, 2, 0);
            this.tableLayoutPanel1.Controls.Add(this.button2, 0, 0);
            this.tableLayoutPanel1.Location = new System.Drawing.Point(9, 11);
            this.tableLayoutPanel1.Margin = new System.Windows.Forms.Padding(2);
            this.tableLayoutPanel1.Name = "tableLayoutPanel1";
            this.tableLayoutPanel1.RowCount = 1;
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel1.Size = new System.Drawing.Size(772, 30);
            this.tableLayoutPanel1.TabIndex = 4;
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(80, 3);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(71, 23);
            this.button1.TabIndex = 6;
            this.button1.Text = "Foward";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // button_Download
            // 
            this.button_Download.Location = new System.Drawing.Point(696, 2);
            this.button_Download.Margin = new System.Windows.Forms.Padding(2);
            this.button_Download.Name = "button_Download";
            this.button_Download.Size = new System.Drawing.Size(73, 25);
            this.button_Download.TabIndex = 7;
            this.button_Download.Text = "Download";
            this.button_Download.UseVisualStyleBackColor = true;
            this.button_Download.Click += new System.EventHandler(this.button_Download_Click);
            // 
            // button_Source
            // 
            this.button_Source.Location = new System.Drawing.Point(619, 2);
            this.button_Source.Margin = new System.Windows.Forms.Padding(2);
            this.button_Source.Name = "button_Source";
            this.button_Source.Size = new System.Drawing.Size(73, 25);
            this.button_Source.TabIndex = 6;
            this.button_Source.Text = "Source";
            this.button_Source.UseVisualStyleBackColor = true;
            this.button_Source.Click += new System.EventHandler(this.button_Source_Click);
            // 
            // button_Go
            // 
            this.button_Go.Location = new System.Drawing.Point(542, 2);
            this.button_Go.Margin = new System.Windows.Forms.Padding(2);
            this.button_Go.Name = "button_Go";
            this.button_Go.Size = new System.Drawing.Size(73, 25);
            this.button_Go.TabIndex = 5;
            this.button_Go.Text = "Go";
            this.button_Go.UseVisualStyleBackColor = true;
            this.button_Go.Click += new System.EventHandler(this.button_Go_Click);
            // 
            // RichTextBox_URL
            // 
            this.RichTextBox_URL.Location = new System.Drawing.Point(156, 2);
            this.RichTextBox_URL.Margin = new System.Windows.Forms.Padding(2);
            this.RichTextBox_URL.Multiline = false;
            this.RichTextBox_URL.Name = "RichTextBox_URL";
            this.RichTextBox_URL.Size = new System.Drawing.Size(382, 26);
            this.RichTextBox_URL.TabIndex = 4;
            this.RichTextBox_URL.Text = "";
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(3, 3);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(71, 23);
            this.button2.TabIndex = 6;
            this.button2.Text = "Back";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // ProgressBar_Download
            // 
            this.ProgressBar_Download.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.ProgressBar_Download.Location = new System.Drawing.Point(11, 409);
            this.ProgressBar_Download.Margin = new System.Windows.Forms.Padding(2);
            this.ProgressBar_Download.Name = "ProgressBar_Download";
            this.ProgressBar_Download.Size = new System.Drawing.Size(768, 19);
            this.ProgressBar_Download.TabIndex = 5;
            // 
            // Bai04_Main
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(790, 452);
            this.Controls.Add(this.ProgressBar_Download);
            this.Controls.Add(this.tableLayoutPanel1);
            this.Controls.Add(this.MyWebBrowser);
            this.Margin = new System.Windows.Forms.Padding(2);
            this.Name = "Bai04_Main";
            this.Text = "Lab 04 - Bài 04 - 19520958 - 19521457";
            this.Load += new System.EventHandler(this.Bai04_Main_Load);
            this.tableLayoutPanel1.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.WebBrowser MyWebBrowser;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel1;
        private System.Windows.Forms.RichTextBox RichTextBox_URL;
        private System.Windows.Forms.Button button_Download;
        private System.Windows.Forms.Button button_Source;
        private System.Windows.Forms.Button button_Go;
        private System.Windows.Forms.ProgressBar ProgressBar_Download;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button button1;
    }
}


﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using HtmlAgilityPack;
using System.Net;
using System.IO;

namespace Lab04_Bai04
{
    public partial class Bai04_Main : Form
    {
        public static string Content = "";
        bool AllowDownload = false;

        HtmlWeb HtmlAgiWeb = new HtmlWeb();
        HtmlAgilityPack.HtmlDocument HtmlDoc = null;

        public Bai04_Main()
        {
            InitializeComponent();
        }
        //check whether url is accessible
        private bool checkURL(string url)
        {
            if (!(url.Contains("http://") | url.Contains("https://")))
            {
                url = "http://" + url;
            }
            try
            {
                HttpWebRequest request = WebRequest.Create(url) as HttpWebRequest;
                request.Method = "HEAD";
                HttpWebResponse response = request.GetResponse() as HttpWebResponse;
                
                response.Close();
                return (response.StatusCode == HttpStatusCode.OK);
            }
            catch
            {
                return false;
            }
        }
        private void button_Go_Click(object sender, EventArgs e)
        {
            if (RichTextBox_URL.Text == "")
                MessageBox.Show("URL rong thi biet truy cap gi ne", "URL ERROR", MessageBoxButtons.OK);
            else
            {
                bool x = RichTextBox_URL.Text.Contains("http://") | RichTextBox_URL.Text.Contains("https://");
                if (x == false)
                {
                   /* MessageBox.Show("Chung toi van co the truy cap neu thieu giao thuc (HTTP/HTTPS), nhung ban nen them vao lan sau", "URL ERROR", MessageBoxButtons.OK);*/
                }
                bool check = checkURL(RichTextBox_URL.Text);
                if (check == true)
                {
                    MyWebBrowser.Navigate(RichTextBox_URL.Text);
                    MyWebBrowser.DocumentCompleted += MyWebBrowser_DocumentCompleted;
                }
                else MessageBox.Show("Khong truy cap duoc roi", "URL ERROR", MessageBoxButtons.OK);
            }

        }

        private void MyWebBrowser_DocumentCompleted(object sender, WebBrowserDocumentCompletedEventArgs e)
        {
            try
            {
                HtmlDoc = HtmlAgiWeb.Load(MyWebBrowser.Url);
                Content = HtmlDoc.Text;

                AllowDownload = true;
            }
            catch (Exception)
            {
                AllowDownload = false;
                Content = string.Empty;
            }
        }

        private void button_Source_Click(object sender, EventArgs e)
        {
            Source MyWebSource = new Source();
            MyWebSource.Show();
        }

        private void button_Download_Click(object sender, EventArgs e)
        {
            if (AllowDownload == true)
            {
                List<string> DownloadQueue = new List<string>();

                GetCollectionItems(MyWebBrowser, HtmlDoc, "//img", "src", ref DownloadQueue);
                GetCollectionItems(MyWebBrowser, HtmlDoc, "//meta[contains (@property, 'image')]", "content", ref DownloadQueue);
                GetCollectionItems(MyWebBrowser, HtmlDoc, "//link[contains(@rel, 'icon')]", "href", ref DownloadQueue);
                GetCollectionItems(MyWebBrowser, HtmlDoc, "//link[contains(@type, 'css')]", "href", ref DownloadQueue);
                GetCollectionItems(MyWebBrowser, HtmlDoc, "//script[contains(@type, 'javascript')]", "src", ref DownloadQueue);
                GetCollectionItems(MyWebBrowser, HtmlDoc, "//a[contains(@href, '.pdf')]", "href", ref DownloadQueue);

                ProgressBar_Download.Value = 0;
                ProgressBar_Download.Minimum = 0;
                ProgressBar_Download.Maximum = DownloadQueue.Count;

                string dir = AppDomain.CurrentDomain.BaseDirectory + "\\";
                string filename = "index.html";
                string path = dir + filename;

                WebClient wc = new WebClient();
                wc.DownloadFile(MyWebBrowser.Url.AbsoluteUri, path);

                foreach (string Url in DownloadQueue)
                {
                    bool retry = false;
                    bool loopBreak = false;

                    do
                    {
                        try
                        {
                            var DownloadUrl = new Uri(Url);
                            filename = Path.GetFileName(DownloadUrl.AbsolutePath);

                            if (filename.Contains('.'))
                            {
                                path = dir + filename;
                                wc.DownloadFile(Url, path);

                                ProgressBar_Download.Value++;
                            }

                            retry = false;
                        }
                        catch (Exception ex)
                        {
                            var ButtonClicked = MessageBox.Show(ex.ToString(), "Error", MessageBoxButtons.AbortRetryIgnore);

                            switch (ButtonClicked)
                            {
                                case DialogResult.Ignore:
                                    retry = false;
                                    break;
                                case DialogResult.Abort:
                                    retry = false;
                                    loopBreak = true;
                                    break;
                                case DialogResult.Retry:
                                    retry = true;
                                    break;
                            }
                        }
                    } while (retry);

                    if (loopBreak == true) break;
                }

                ProgressBar_Download.Value = 0;
            }
            else
            {
                MessageBox.Show("The website is not available.", "Error");
                return;
            }
        }

        void GetCollectionItems(WebBrowser browser, HtmlAgilityPack.HtmlDocument HtmlDoc, string XPath, string attribute, ref List<string> StringCollection)
        {
            HtmlNodeCollection HtmlCollection = HtmlDoc.DocumentNode.SelectNodes(XPath);

            if (HtmlCollection != null)
            {
                foreach (HtmlNode node in HtmlCollection)
                {
                    string RelativeUri = node.GetAttributeValue(attribute, "");

                    if (RelativeUri != string.Empty)
                    {
                        var AbsoluteUrl = new Uri(browser.Url, RelativeUri);

                        if (StringCollection.IndexOf(AbsoluteUrl.AbsoluteUri) == -1)
                        {
                            StringCollection.Add(AbsoluteUrl.AbsoluteUri);
                        }
                    }
                }
            }
        }

        private void Bai04_Main_Load(object sender, EventArgs e)
        {

        }

        private void MyWebBrowser_DocumentCompleted_1(object sender, WebBrowserDocumentCompletedEventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (MyWebBrowser.CanGoBack)
            {
                MyWebBrowser.GoBack();
                RichTextBox_URL.Text = MyWebBrowser.Url.ToString();
                MyWebBrowser.DocumentCompleted += MyWebBrowser_DocumentCompleted;
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (MyWebBrowser.CanGoForward)
            {
                MyWebBrowser.GoForward();
                RichTextBox_URL.Text = MyWebBrowser.Url.ToString();
                MyWebBrowser.DocumentCompleted += MyWebBrowser_DocumentCompleted;
            }
        }
    }
}

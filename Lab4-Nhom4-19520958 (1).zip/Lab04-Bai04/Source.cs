﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Net;

namespace Lab04_Bai04
{
    public partial class Source : Form
    {
        public Source()
        {
            InitializeComponent();
        }

        private void Source_FormLoad(object sender, EventArgs e)
        {
            RichTextBox_Response.Text = Bai04_Main.Content;
        }

        private void RichTextBox_Response_TextChanged(object sender, EventArgs e)
        {

        }
    }
}

﻿
namespace Lab04_Bai04
{
    partial class Source
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.RichTextBox_Response = new System.Windows.Forms.RichTextBox();
            this.SuspendLayout();
            // 
            // RichTextBox_Response
            // 
            this.RichTextBox_Response.Dock = System.Windows.Forms.DockStyle.Fill;
            this.RichTextBox_Response.Location = new System.Drawing.Point(0, 0);
            this.RichTextBox_Response.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.RichTextBox_Response.Name = "RichTextBox_Response";
            this.RichTextBox_Response.ReadOnly = true;
            this.RichTextBox_Response.Size = new System.Drawing.Size(600, 366);
            this.RichTextBox_Response.TabIndex = 0;
            this.RichTextBox_Response.Text = "";
            this.RichTextBox_Response.TextChanged += new System.EventHandler(this.RichTextBox_Response_TextChanged);
            // 
            // Source
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(600, 366);
            this.Controls.Add(this.RichTextBox_Response);
            this.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.Name = "Source";
            this.Text = "Source";
            this.Load += new System.EventHandler(this.Source_FormLoad);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.RichTextBox RichTextBox_Response;
    }
}